#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile
from geometry_msgs.msg import Twist
from ackermann_msgs.msg import AckermannDriveStamped
from gazebo_msgs.msg import ModelStates
from turtlebot_stl_ros2.msg import STLInfo
from tf_transformations import euler_from_quaternion
import math
import sys, select, termios, tty
from cvxopt import solvers, matrix
import numpy as np

from util import print_c, format_color_log

class STLFinish(Node):
    def __init__(self):
        super().__init__('parameter_reader')

        # Declare parameters
        self.declare_parameter('pos_x', 0.0)
        self.declare_parameter('pos_y', 0.0)
        self.declare_parameter('goals', [])
        self.declare_parameter('obstacles', [])
        self.declare_parameter('is_avoiding_obstacle', 0)
        self.declare_parameter('dist_goal', 0.2)
        self.declare_parameter('dist_obs', 0.15)

        # Read parameters
        pos_x = self.get_parameter('pos_x').get_parameter_value().double_value
        pos_y = self.get_parameter('pos_y').get_parameter_value().double_value

        goals = self.get_parameter('goals').get_parameter_value().double_array_value
        obstacles = self.get_parameter('obstacles').get_parameter_value().double_array_value

        is_avoiding_obstacle = self.get_parameter('is_avoiding_obstacle').get_parameter_value().integer_value
        dist_goal = self.get_parameter('dist_goal').get_parameter_value().double_value
        dist_obs = self.get_parameter('dist_obs').get_parameter_value().double_value

        # Parse and log parameters
        self.get_logger().info(f"Vehicle Position -> x: {pos_x}, y: {pos_y}")

        # Parse goals
        parsed_goals = [
            {"x": goals[i], "y": goals[i+1], "start": goals[i+2], "end": goals[i+3], "expect": goals[i+4]}
            for i in range(0, len(goals), 5)
        ]
        self.get_logger().info(f"Goals: {parsed_goals}")

        # Parse obstacles
        parsed_obstacles = [
            {"x": obstacles[i], "y": obstacles[i+1], "r": obstacles[i+2], "vx": obstacles[i+3], "vy": obstacles[i+4]}
            for i in range(0, len(obstacles), 5)
        ]
        self.get_logger().info(f"Obstacles: {parsed_obstacles}")

        # Log other parameters
        self.get_logger().info(format_color_log(f"Is Avoiding Obstacles: {bool(is_avoiding_obstacle)}", color="green", style="italic"))
        self.get_logger().info(format_color_log(f"Distance to Goal: {dist_goal}", color="green", style="italic"))
        self.get_logger().info(format_color_log(f"Distance to Obstacle: {dist_obs}", color="green", style="italic"))


def main(args=None):
    rclpy.init(args=args)
    node = STLFinish()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
