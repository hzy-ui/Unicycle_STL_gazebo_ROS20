**Quick Start**
1.Launch the Gazebo environment:
    roslaunch <your_package_name> mycar_gazebo.launch
2.Run the control script:
    rosrun <your_package_name> stl_control_car.py

**Related document description**
1.document1： jackel
    Description： Description files and control files for nonholonomic vehicles.

2.document2： mycar_gazebo
    Description： Open the car file, enable chassis control, and load STL specifications in Gazebo.
    Files:
        mycar_gazebo.launch :               Loads the world, car, and STL specifications.
        world_with_no_obstacles.world :     Scene with obstacles.
        world_with_no_obstacles.world :     Scene without obstacles.

3.document3: stl_control
    Description: Open the car file, enable chassis control, and load STL specifications in Gazebo.
    Files:
        set_param.py :      Configures STL specifications.
        stl_control.py :    Main control script.
