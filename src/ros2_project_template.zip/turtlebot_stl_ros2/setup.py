#!/usr/bin/env python3

from setuptools import setup

package_name = 'turtlebot_stl_ros2'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
)
